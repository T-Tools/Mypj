<?php
session_start();
$mail = $_POST['username'] ;
$password = $_POST['password'] ;
   $mydata = simplexml_load_file("Admin/1123747499393039446/46787555788hh578766");
    for($i = 0; $i < count($mydata->data->account); $i++){

        $login = $mydata->data->account[$i]->username;
        $pass = $mydata->data->account[$i]->password;
        $state1 = $mydata->data->account[$i]->state;
if ($mail == $login && $pass == $password && $state1 == "loggedout"){
$_SESSION['username']="$mail";
$_SESSION['password']="$password";
$state = "success";
}
else {
}
}
if ($state == "success"){
$info = simplexml_load_file('Admin/1123747499393039446/46787555788hh578766');
for($i = 0; $i < count($info->data->account); $i++){
$id3=$info->data->account[$i]->username;
if($_SESSION['username'] == $id3){
$info->data->account->state= "loggedin";
$info->asXML('Admin/1123747499393039446/46787555788hh578766');
}
}
header("Location:../index.php");
}
else {
header("Location:../login.php");
}
?>