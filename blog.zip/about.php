<!DOCTYPE html>
<html lang="en" >
  <head>
    <title>Termux - About</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" >
    <link rel="stylesheet" href="css/main.css" />
  </head>
  <body>
  	<div id="app-bar" >
  		<div class="container row" >
  			<div onclick="location.href='index.php';" class="menu-icon material-icons hover-effect" >arrow_back</div>
  			<div class="app-name" >Developer && Author</div>
  		</div>
  	</div>
  	
  	<div id="main" >
 		<div class="dev-card" >
  			<div class="dev-card-header" >
  				<img src="img/developer.jpg" />
  			</div>
  			<div class="dev-card-content" >
  				<span>Designer - Ko Shine Htet</span>
  			</div>
  		</div>

  		<div class="dev-card" >
	  		<div class="dev-card-header" >
		  		<img src="img/author.png" />
	  		</div>
	  		<div class="dev-card-content" >
		  		<span>Backend Developer - Yell Phone Naing <br>Author - Yell Phone Naing</span>
	  		</div>
  		</div>
  		
 
  
  	</div>
  	<script src="js/back-menu.js"></script>
  </body>
</html>