<?php
session_start();
include("check.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Termux Tutorial For Beginners</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/main.css" />
</head>
<body>
	<div id="app-bar">
        <div class="container row">
            <div class="menu-icon material-icons hover-effect" onclick="drawerToggle(true)">
                menu
            </div>
            <div class="app-name">
               Termux Tutorial For Beginners
            </div>
        </div>
    </div>
    <div id="drawer-layout">
        <div class="drawer-header" >
    	<img src="img/drawer-header.png"/>
        </div>
        <div class="drawer-items" >
        	<div class="item row hover-effect" data-id="pre_dev_env" onclick="location.href='posts.php';">
	        	<div class="icon material-icons" >book</div>
	        	<div class="name" >Posts</div>
        	</div>
        	
        	<div class="item row hover-effect" data-id="php_basic" onclick="location.href='bash.php';">
	        	<div class="icon material-icons" >code</div>
	        	<div class="name" >BASH Basic</div>
        	</div>
        	
        	<div class="item row hover-effect" data-id="ui_basic" onclick="location.href='chatroom.php';">
	        	<div class="icon material-icons" >chat</div>
	        	<div class="name" >Chat Room</div>
        	</div>
        	
        	<div class="item row hover-effect" data-id="info" onclick="location.href='about.php';">
	        	<div class="icon material-icons" >info</div>
	        	<div class="name" >Developer && Author</div>
        	</div>
	<div class="item row hover-effect" data-id="ui_basic" onclick="location.href='logout.php';">
	        	<div class="icon material-icons" ></div>
	        	<div class="name" >Logout</div>
        	</div>
        </div>
    </div>
  	
       
    <div id="drawer-overlay" onclick="drawerToggle(false)"></div>

    <div id="loader"></div>
    <!-- MAIN -->
    <div id="main">
    <?php
$mydata = simplexml_load_file("Admin/1123747499393039446/4789955645789755");
    for($i = 0; $i < count($mydata->data->post); $i++){
$id=$mydata->data->post[$i]->id;
$title=$mydata->data->post[$i]->title;
$date=$mydata->data->post[$i]->date;

echo "<a style='color:black;' href='post.php?id=$id'>
<div class='card row'>
<div class='col-1'>
<div class='icon'>YPN</div>
</div>
<div class='col-2'>
<div class='row-1'>
<div class='title'>$title
</div>
</div>
<div class='row-2'>
<div class='row'>
<div class='material-icons'>event</div>
<div class='date'>$date</div>
</div></div></div></div></a>";
}
?>
</div>

</div>
    
   
    <script src="js/main.js"></script>
</body>
</html>