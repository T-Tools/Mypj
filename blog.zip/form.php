<?php
session_start();
include("check.php");
?>
<?php
session_start();
if($_POST['message']){
$mydata = simplexml_load_file("Admin/1123747499393039446/566777558885677");
    for($i = 0; $i < count($mydata->data->chat); $i++){
$name= $_SESSION['username'] ;
$date=date("d.m.y(h:i:s)");
$text= htmlspecialchars( $_POST[ 'message' ]);
$resultNext = $mydata->data->chat->addchild('body');
$resultNext->addChild('name', $name);
$resultNext->addChild('message', $text);
$resultNext->addChild('time', $date);
$mydata->asXml('Admin/1123747499393039446/566777558885677');
}
header("Location:../form.php");
}


?>
<style>
body {
  margin: 0 auto;
  max-width: 800px;
  padding: 0 20px;
}

#searchbar {
  border-radius: 7px;
  bottom: 10px;
  left: 0;
  border: 2px solod skyblue;
  width: 100%;
  height:100%;
  margin-left: auto;
  margin-right: auto;
  text-align: center;
  background-color:grey;
}
textarea {
  width: 100%;
  padding: 10px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 2px solid red;
  border-radius: 4px;
}
.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 15px 322px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

.send {
    width: 80px;  
   background-color: white; 
  color: red; 
  border: 2px solid blue;
}

.container {
  border: 2px solid #dedede;
  background-color: #f1f1f1;
  border-radius: 5px;
  padding: 10px;
  margin: 10px 0;
}
.darker {
  border-color: #ccc;
  background-color: #ddd;
}

.container::after {
  content: "";
  clear: both;
  display: table;
}
.container img {
  float: left;
  max-width: 60px;
  width: 100%;
  margin-right: 20px;
  border-radius: 50%;
}

.container img.right {
  float: right;
  margin-left: 20px;
  margin-right:0;
}

.time-right {
  float: right;
  color: #aaa;
}
.time-right {
  float: right;
  color: #aaa;
}


</style><br>
<div id="searchbar">
        <form action="#" class="form-wrapper" method="post">
            <div class="input-chat">
             <textarea rows='3' class='form-control' placeholder='Write Here' name='message'></textarea>
            </div>
            <button class="send" type="submit">Send</button>
        </form>
    </div>

</div>