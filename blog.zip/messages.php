<?php
session_start();
include("check.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="5">
  <link rel="stylesheet" href="css/main.css" />
<style>
body {
  margin: 0 auto;
  max-width: 800px;
  padding: 0 20px;
}

#searchbar {
  border-radius: 7px;
  bottom: 20px;
  left: 0;
  width: 100%;
  margin-left: auto;
  margin-right: auto;
  text-align: center;
  background-color:grey;
}
input[type=text] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 2px solid red;
  border-radius: 4px;
}
.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

.send {
    width: 80px;  
   background-color: white; 
  color: red; 
  border: 2px solid blue;
}

.container {
  border: 2px solid #dedede;
  background-color: #f1f1f1;
  border-radius: 5px;
  padding: 10px;
  margin: 10px 0;
}
.darker {
  border-color: #ccc;
  background-color: #ddd;
}

.container::after {
  content: "";
  clear: both;
  display: table;
}
.container img {
  float: left;
  max-width: 60px;
  width: 100%;
  margin-right: 20px;
  border-radius: 50%;
}

.container img.right {
  float: right;
  margin-left: 20px;
  margin-right:0;
}

.time-right {
  float: right;
  color: #aaa;
}
.time-right {
  float: right;
  color: #aaa;
}


</style>
<html>

 <?php
$mydata = simplexml_load_file("Admin/1123747499393039446/566777558885677");
    for($i = 0; $i < count($mydata->data->chat->body); $i++){
$name=$mydata->data->chat->body[$i]->name;
$message=$mydata->data->chat->body[$i]->message;
$time=$mydata->data->chat->body[$i]->time;
$name1=htmlspecialchars($name);
$message1=htmlspecialchars($message);
$time1=htmlspecialchars($time);
echo '<div class="container">
  <img src="img/user.jpg" alt="Avatar" style="width:100%;">
<h3>'.$name1.'</h3>
  <p>'.$message1.'</p>
  <span class="time-right">'.$time1.'</span>
</div>';
}
?>
</div>
</div>
 <script src="js/main.js"></script>
</body>
</html>
