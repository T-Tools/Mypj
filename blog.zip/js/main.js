const drawerLayout = document.getElementById("drawer-layout");
const drawerOverlay = document.getElementById("drawer-overlay");

function drawerToggle(b) {
    (b) ? drawer.open() : drawer.close();
}

function drawerItemSelected(data){
	drawer.close();
	switch(drawer.selectedItem(data)){
		case "pre_dev_env":
			window.location.href = "./label-by-post.html?label=preparing_developement_environment";
			break;
			
		case "php_basic":
			window.location.href = "./label-by-post.html?label=php_basic";
			break;
			
		case "ui_basic":
			window.location.href = "./label-by-post.html?label=ui_basic";
			break;
		
		case "info":
			window.location.href = "./dev-and-author.html";
			break;
	}
}

var drawer = {
    open: function() {
        drawerLayout.classList.remove("dLayoutClose");
        drawerOverlay.classList.remove("dOverlayClose");
        drawerLayout.classList.add("dLayoutOpen");
        drawerOverlay.classList.add("dOverlayOpen");
        drawerLayout.style.display = "block";
        drawerOverlay.style.display = "block";
    },

    close: function() {
        drawerLayout.classList.remove("dLayoutOpen");
        drawerOverlay.classList.remove("dOverlayOpen");
        drawerLayout.classList.add("dLayoutClose");
        drawerOverlay.classList.add("dOverlayClose");
        drawerOverlay.style.display = "none";
        setTimeout(function() {
            drawerLayout.style.display = "none";
        }, 300);
    },
    
    selectedItem : function(data) {
    	return data.getAttribute("data-id");
    }
}

jQuery.event.add(window, "load", function(){
	setUpMainLayout();
	$("#loader").show();
	$("#erro-page").hide();
	
	$.ajax({
		url : atob(app.host()),
		dataType : "jsonp"
	})
	.done(function(data){
		$("#loader").hide();
		app.loadData($("#main"), data);
	})
	.fail(function(){
		$("#loader").hide();
		$("#erro-page").show();
	});
});

function getDataFromUrl(url) {
	$.ajax({
		url : url,
		dataType : "jsonp"
	})
	.done(function(data){
		$("#loader").hide();
		app.loadData($("#main"), data);
		$(".load-more").hide();
	})
	.fail(function(){
		$(".load-more").last().html("Load More");
		$("#loader").hide();
	});
}

var app = {
	host : function() {
		return "aHR0cHM6Ly93d3cuZ29vZ2xlYXBpcy5jb20vYmxvZ2dlci92My9ibG9ncy80ODIwNjc3NzgyODA1NjE1MzA5L3Bvc3RzP2tleT1BSXphU3lCd0N1ck5tRXRvWWxha1RUakFWQ1Q1R2V3aXNaMUhyUGc";
	},
	
	apiKey : function() {
		return "QUl6YVN5QndDdXJObUV0b1lsYWtUVGpBVkNUNUdld2lzWjFIclBn";
	},
	
	dateFormat : function(updatedTime) {
		let year = updatedTime.substring(0, 4);
		let month = updatedTime.substring(5, 7);
		let day = updatedTime.substring(8, 10);
		let monthArr = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
		return year + " /" + monthArr[month-1] + " /" + day;
	},
	
	iconGenerator : function(t, c) {
		let imgStartTag = c.indexOf('<img');
		let imgEndTag = c.indexOf('</a>');
		
		if (imgStartTag < imgEndTag) {
			return c.substring(imgStartTag, imgEndTag);
		} else {
			return t.charAt(0);
		}
	},
	
	loadMore : function(obj) {
		$(".load-more").last().html(view.smallLoader());
		let nextPageUrl = atob(app.host())+"&pageToken="+obj.getAttribute("data-token");
		getDataFromUrl(nextPageUrl);
	},
	
	loadData : function(v, data){
		let obj = JSON.parse(JSON.stringify(data));
		let items = obj.items;
		for(let i = 0; i < items.length; i++){
			let title = items[i].title;
			let content = items[i].content;
			let date = app.dateFormat(items[i].updated);
			let icon = app.iconGenerator(title, content);
			let selfLink = items[i].selfLink;
			v.append(view.card(selfLink, title, icon, date));
		}
		if(obj.nextPageToken == undefined){
			v.append(view.pageEnd());
		} else {
			v.append(view.loadMore(obj.nextPageToken));
		}
	}
	
}

var view = {
	card : function(selfLink, title, icon, date) {
		return "<div class='card row' data-selflink="+selfLink+" onclick='viewPost(this)'>"+
			"<div class='col-1'>"+
				"<div class='icon'>"+icon+"</div>"+
			"</div>"+
			"<div class='col-2'>"+
				"<div class='row-1'>"+
					"<div class='title'>"+title+"</div>"+
				"</div>"+
				"<div class='row-2'>"+
					"<div class='row'>"+
						"<div class='material-icons'>event</div>"+
						"<div class='date'>"+date+"</div>"+
					"</div>"+
				"</div>"+
			"</div>"+
		"</div>";
	},
	
	smallLoader : function() {
		return "<div class='small-loader'></div>";
	},
	
	loadMore : function(token) {
		return "<div class='load-more' data-token="+token+" onclick='app.loadMore(this)'>Load More</div>";
	},
	
	pageEnd : function() {
		return "<div class='page-end'>No More Result</div>";
	}
}

var appBar = $("#app-bar");
var main = $("#main");

function setUpMainLayout() {
	main.css("margin-top", appBar.height() + "px");
	main.height(window.innerHeight - appBar.height());
}

function viewPost(obj){
	let selfLink = obj.getAttribute("data-selflink");
	let postId = selfLink.substring(70, selfLink.length);
	window.location.href = "./post-viewer.html?p="+btoa(postId);
}