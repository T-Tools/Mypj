<?php
session_start();
session_destroy();
$info = simplexml_load_file('Admin/1123747499393039446/46787555788hh578766');
for($i = 0; $i < count($info->data->account); $i++){
$id3=$info->data->account[$i]->username;
if($_SESSION['username'] == $id3){
$info->data->account->state= "loggedout";
$info->asXML('Admin/1123747499393039446/46787555788hh578766');
}
}
header("location:index.php");
?>