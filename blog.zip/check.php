<?php
session_start();
$mail = $_SESSION['username'] ;
$password = $_SESSION['password'] ;
$mydata = simplexml_load_file("Admin/1123747499393039446/46787555788hh578766");
    for($i = 0; $i < count($mydata->data->account); $i++){

        $login = $mydata->data->account[$i]->username;
        $pass = $mydata->data->account[$i]->password;
if ($mail == $login && $pass == $password){
$state = "success";
}
else {
}
}
if ($state == "success" ){
}
else {
header("Location:../login.php");
}
?>