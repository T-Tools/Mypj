<?php
session_start();
$info = simplexml_load_file('1123747499393039446/47899556sjwjwj26192878');
for($i = 0; $i < count($info->data->account); $i++){
$pass=$info->data->account[$i]->password;
if($_SESSION['password'] == $pass){
$info->data->account->username=$_POST['username'];
$info->data->account->password=$_POST['password'];
$info->asXML('1123747499393039446/47899556sjwjwj26192878');
header("location:admin_logout.php");
}
}
?>