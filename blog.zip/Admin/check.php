<?php
session_start();
$mail = $_SESSION['name'] ;
$password = $_SESSION['pass'] ;
   $mydata = simplexml_load_file("1123747499393039446/47899556sjwjwj26192878");
    for($i = 0; $i < count($mydata->data->account); $i++){

        $login = $mydata->data->account[$i]->username;
        $pass = $mydata->data->account[$i]->password;
if ($mail == $login && $pass == $password){
}
else {
header("Location:index.php");
}
}
?>