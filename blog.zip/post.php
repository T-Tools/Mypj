<?php
session_start();
include("check.php");
?>
<!DOCTYPE html>
<html lang="en" >
  <head>
    <title>Termux - View Post</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" >
    <link rel="stylesheet" href="css/main.css" />
  </head>
  <body>
  	<div id="app-bar" >
  		<div class="container row" >
  			<div onclick="location.href='index.php';" class="menu-icon material-icons" >arrow_back</div>
  			<div class="app-name" >Termux Tutorials For Beginners</div>
  		</div>
  	</div>
  	<div id="loader" ></div>
  	<div id="main" >
   <?php
$mydata = simplexml_load_file("Admin/1123747499393039446/4789955645789755");
    for($i = 0; $i < count($mydata->data->post); $i++){
$id1=$mydata->data->post[$i]->id;
$title=$mydata->data->post[$i]->title;
$date=$mydata->data->post[$i]->date;
$text=$mydata->data->post[$i]->text;
$id=$_GET['id'];
$id2=preg_replace("([A-Z]+[a-z]+[<]+[>]+)", "  ", $id);
if ($id2 == $id1){
echo '<div class="view-post">
<div class="view-header row">
<div class="row">
<span class="material-icons">event</span>
<span class="ubuntu" style="margin-left: 10px;">'.$date.'</span>
</div>
</div>
<div class="unicode title">'.$title.'</div>
<div class="view-content unicode">
<p class="sub-title">'.$text.'</p>
</div>';
}
}
?>
  </body>
</html>