    

<html>
<title>Termux-Login</title>
<!--Favicon-->
	

<!---CSS dan Tampilan--->
<style>
/* unvisited link */
a:link {
    color: yellow;
}
button {
width:100px;
heigh:20%;
color:blue;
background-color:red;
}

/* visited link */
a:visited {
    color: cyan;
}

/* mouse over link */
a:hover {
    color: white;
}

/* selected link */
a:active {
    color: green;
}
		
		.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 15px 15px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 15px;
}
		
	body {
		background-image: url("bg.jpg"); 
		background-color: #000000;
		color: #FF0000;
		text-align: center;
		font-family: helvetica;
		font-size: 14px;
		margin: 10% auto auto auto;
	}
	
	#pesan {
		background-color: #000000;
		width: 40%;
		padding: 20px;
		border: 2px solid #f00;
		margin: 0px auto auto auto;
	}
	
	form {
		color: #f00;
	}
	
	input {
		border: 1px solid #f00;
		padding: 10px;
		background: #000;
		color: #f00;
	}
	
	input[type=text] {
		width: 500px;
	}
	
<!---Konten 1--->	
	</style>
</head>
<body>
	<div id="pesan">
	<center><a href=><img src=logo.png height=300 width=350 alt="#" /></a></center>
	<br>

	<br>
	<font face="arial" color="cyan" size="3">Termux Tutorials By CyberBullet</a></center><br>
	<br>
	<font face="arial" color="yellow" size="3">Please Login To Your Account.<br>Memberဝင်ရန်အတွက်ဆက်သွယ်ပေးပါ<br>Phone: 09890416408</font></a></center><br>
   <br>
      <form action="ceklogin.php" method="post">
            <div>
            Username:
            <br/>
            <input type="" name="username" size="14" value="<?php echo $_SESSION['username'];?>" />
            <br/>
            Password:
            <br/>
            <input type="password" name="password" size="14" />
            <br/><br/>
            <button name="login" type="submit">Login</button>
            </div>
      </form>
   	
    </div>
	<p>&nbsp;</p>
