<?php
session_start();
include("check.php");
?>
<!DOCTYPE html>
<html>
<head>
<title>Termux | Chat Room</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/main.css" />
<style>
body {
  margin: 0 auto;
  max-width: 800px;
  padding: 0 20px;
}

#searchbar {
  border-radius: 7px;
  bottom: 20px;
  left: 0;
  width: 100%;
  margin-left: auto;
  margin-right: auto;
  text-align: center;
  background-color:grey;
}
input[type=text] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 2px solid red;
  border-radius: 4px;
}
.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

.send {
    width: 80px;  
   background-color: white; 
  color: red; 
  border: 2px solid blue;
}

.container {
  border: 2px solid #dedede;
  background-color: #f1f1f1;
  border-radius: 5px;
  padding: 10px;
  margin: 10px 0;
}
.darker {
  border-color: #ccc;
  background-color: #ddd;
}

.container::after {
  content: "";
  clear: both;
  display: table;
}
.container img {
  float: left;
  max-width: 60px;
  width: 100%;
  margin-right: 20px;
  border-radius: 50%;
}

.container img.right {
  float: right;
  margin-left: 20px;
  margin-right:0;
}

.time-right {
  float: right;
  color: #aaa;
}
.time-right {
  float: right;
  color: #aaa;
}


</style>

<frameset rows="65%,35%" framespacing="1" frameborder="yes" border="1" bordercolor="green">
   
  <frame src="messages.php" name="main_frame">
<br>
  <frame src="form.php" name="main_frame">
</frameset>
